#include <QApplication>
#include <QComboBox>
#include <QDateTime>
#include <QDateTimeEdit>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QPainterPath>
#include <QProgressBar>
#include <QPushButton>
#include <QStringList>
#include <QVBoxLayout>
#include <QWidget>

#include <cmath>

namespace {
constexpr double kSynodicMonthDays = 29.530588853;
constexpr double kTropicalYearDays = 365.2422;
constexpr double kSecondsPerDay = 86400.0;
constexpr double kMoonEpochUnixSeconds = 947182440.0; // 2000-01-06 18:14 UTC
constexpr double kSolarEpochUnixSeconds = 953537700.0; // 2000-03-20 07:35 UTC
constexpr double kPi = 3.14159265358979323846;

double positiveModulo(double value, double modulus)
{
    return std::fmod(std::fmod(value, modulus) + modulus, modulus);
}

QString lunarPhaseName(double phase)
{
    if (phase < 0.03 || phase >= 0.97) return QStringLiteral("New Moon");
    if (phase < 0.22) return QStringLiteral("Waxing Crescent");
    if (phase < 0.28) return QStringLiteral("First Quarter");
    if (phase < 0.47) return QStringLiteral("Waxing Gibbous");
    if (phase < 0.53) return QStringLiteral("Full Moon");
    if (phase < 0.72) return QStringLiteral("Waning Gibbous");
    if (phase < 0.78) return QStringLiteral("Last Quarter");
    return QStringLiteral("Waning Crescent");
}

QStringList seasonNames(bool southernHemisphere)
{
    if (southernHemisphere) {
        return {QStringLiteral("Autumn"), QStringLiteral("Winter"),
                QStringLiteral("Spring"), QStringLiteral("Summer")};
    }
    return {QStringLiteral("Spring"), QStringLiteral("Summer"),
            QStringLiteral("Autumn"), QStringLiteral("Winter")};
}

class MoonWidget final : public QWidget {
public:
    explicit MoonWidget(QWidget *parent = nullptr) : QWidget(parent)
    {
        setMinimumSize(132, 132);
        setMaximumSize(160, 160);
    }

    void setPhase(double phase)
    {
        m_phase = phase;
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        const qreal diameter = qMin(width(), height()) - 12.0;
        const QRectF disk((width() - diameter) / 2.0, (height() - diameter) / 2.0,
                          diameter, diameter);
        const qreal radius = diameter / 2.0;

        painter.setPen(Qt::NoPen);
        painter.setBrush(QColor(QStringLiteral("#202b3b")));
        painter.drawEllipse(disk);

        const bool waxing = m_phase <= 0.5;
        const double visiblePhase = waxing ? m_phase : 1.0 - m_phase;
        const double terminator = std::cos(2.0 * kPi * visiblePhase);
        QPainterPath litArea;
        constexpr int steps = 100;
        for (int i = 0; i <= steps; ++i) {
            const double y = -1.0 + 2.0 * i / steps;
            const double edge = std::sqrt(qMax(0.0, 1.0 - y * y));
            const double x = terminator * edge;
            const QPointF point(disk.center().x() + (waxing ? x : -x) * radius,
                                disk.center().y() + y * radius);
            if (i == 0) litArea.moveTo(point);
            else litArea.lineTo(point);
        }
        for (int i = steps; i >= 0; --i) {
            const double y = -1.0 + 2.0 * i / steps;
            const double edge = std::sqrt(qMax(0.0, 1.0 - y * y));
            const double x = waxing ? edge : -edge;
            litArea.lineTo(disk.center().x() + x * radius,
                           disk.center().y() + y * radius);
        }
        litArea.closeSubpath();
        painter.setBrush(QColor(QStringLiteral("#f4e9c9")));
        painter.drawPath(litArea);

        painter.setPen(QPen(QColor(QStringLiteral("#57657a")), 1.0));
        painter.setBrush(Qt::NoBrush);
        painter.drawEllipse(disk);
    }

private:
    double m_phase = 0.0;
};

QFrame *makeCard()
{
    auto *card = new QFrame;
    card->setObjectName(QStringLiteral("card"));
    card->setFrameShape(QFrame::StyledPanel);
    return card;
}

QLabel *makeValueLabel(const QString &text = QString())
{
    auto *label = new QLabel(text);
    label->setObjectName(QStringLiteral("value"));
    label->setWordWrap(true);
    return label;
}

class TrackerWindow final : public QWidget {
public:
    TrackerWindow()
    {
        setWindowTitle(QStringLiteral("Luna & Sol — Cycle Tracker"));
        resize(760, 700);
        setMinimumSize(620, 600);
        setStyleSheet(QStringLiteral(
            "QWidget { background: #101722; color: #e7edf5; font-family: sans-serif; }"
            "QLabel#subtitle { color: #9eacbf; }"
            "QLabel#sectionTitle { font-size: 18px; font-weight: 600; }"
            "QLabel#value { font-size: 15px; font-weight: 500; }"
            "QFrame#card { background: #182231; border: 1px solid #2b394c; "
            "border-radius: 12px; }"
            "QDateTimeEdit, QComboBox { background: #202d3e; border: 1px solid #3b4a60; "
            "border-radius: 6px; padding: 7px; min-width: 175px; }"
            "QPushButton { background: #d9c58f; color: #17202b; border: 0; "
            "border-radius: 6px; padding: 8px 12px; font-weight: 600; }"
            "QPushButton:hover { background: #ead9aa; }"
            "QProgressBar { background: #202d3e; border: 0; border-radius: 5px; "
            "height: 10px; text-align: center; }"
            "QProgressBar::chunk { background: #d9c58f; border-radius: 5px; }"));

        auto *root = new QVBoxLayout(this);
        root->setContentsMargins(28, 24, 28, 20);
        root->setSpacing(16);

        auto *title = new QLabel(QStringLiteral("Luna & Sol"));
        QFont titleFont = title->font();
        titleFont.setPointSize(26);
        titleFont.setBold(true);
        title->setFont(titleFont);
        auto *subtitle = new QLabel(QStringLiteral("A quiet view of the lunar phases and solar year"));
        subtitle->setObjectName(QStringLiteral("subtitle"));
        root->addWidget(title);
        root->addWidget(subtitle);

        auto *controls = makeCard();
        auto *controlsLayout = new QHBoxLayout(controls);
        controlsLayout->setContentsMargins(16, 12, 16, 12);
        auto *whenLabel = new QLabel(QStringLiteral("Date and time"));
        m_dateTime = new QDateTimeEdit(QDateTime::currentDateTime());
        m_dateTime->setCalendarPopup(true);
        m_dateTime->setDisplayFormat(QStringLiteral("ddd, d MMM yyyy  HH:mm"));
        m_hemisphere = new QComboBox;
        m_hemisphere->addItem(QStringLiteral("Northern hemisphere"), false);
        m_hemisphere->addItem(QStringLiteral("Southern hemisphere"), true);
        auto *nowButton = new QPushButton(QStringLiteral("Now"));
        controlsLayout->addWidget(whenLabel);
        controlsLayout->addWidget(m_dateTime, 1);
        controlsLayout->addWidget(m_hemisphere);
        controlsLayout->addWidget(nowButton);
        root->addWidget(controls);

        auto *cards = new QHBoxLayout;
        cards->setSpacing(16);
        cards->addWidget(createLunarCard());
        cards->addWidget(createSolarCard());
        root->addLayout(cards, 1);

        auto *note = new QLabel(QStringLiteral(
            "Cycle dates are estimates based on average cycle lengths. "
            "This offline tracker does not calculate local sunrise, sunset, or visibility."));
        note->setObjectName(QStringLiteral("subtitle"));
        note->setWordWrap(true);
        root->addWidget(note);

        connect(m_dateTime, &QDateTimeEdit::dateTimeChanged, this, [this] { updateReadings(); });
        connect(m_hemisphere, qOverload<int>(&QComboBox::currentIndexChanged),
                this, [this] { updateReadings(); });
        connect(nowButton, &QPushButton::clicked, this, [this] {
            m_dateTime->setDateTime(QDateTime::currentDateTime());
        });
        updateReadings();
    }

private:
    QWidget *createLunarCard()
    {
        auto *card = makeCard();
        auto *layout = new QVBoxLayout(card);
        layout->setContentsMargins(18, 18, 18, 18);
        layout->setSpacing(12);
        auto *heading = new QLabel(QStringLiteral("Lunar cycle"));
        heading->setObjectName(QStringLiteral("sectionTitle"));
        layout->addWidget(heading);
        auto *top = new QHBoxLayout;
        m_moon = new MoonWidget;
        auto *details = new QVBoxLayout;
        m_moonPhase = makeValueLabel();
        m_illumination = new QLabel;
        m_illumination->setObjectName(QStringLiteral("subtitle"));
        m_moonAge = new QLabel;
        m_moonAge->setObjectName(QStringLiteral("subtitle"));
        details->addWidget(m_moonPhase);
        details->addWidget(m_illumination);
        details->addWidget(m_moonAge);
        details->addStretch();
        top->addWidget(m_moon, 0, Qt::AlignCenter);
        top->addLayout(details, 1);
        layout->addLayout(top);

        auto *nextHeading = new QLabel(QStringLiteral("Next major phase"));
        nextHeading->setObjectName(QStringLiteral("subtitle"));
        m_nextMoon = makeValueLabel();
        layout->addWidget(nextHeading);
        layout->addWidget(m_nextMoon);
        layout->addStretch();
        return card;
    }

    QWidget *createSolarCard()
    {
        auto *card = makeCard();
        auto *layout = new QVBoxLayout(card);
        layout->setContentsMargins(18, 18, 18, 18);
        layout->setSpacing(12);
        auto *heading = new QLabel(QStringLiteral("Solar year"));
        heading->setObjectName(QStringLiteral("sectionTitle"));
        layout->addWidget(heading);
        m_solarSeason = makeValueLabel();
        layout->addWidget(m_solarSeason);
        m_solarProgress = new QProgressBar;
        m_solarProgress->setRange(0, 1000);
        m_solarProgress->setTextVisible(false);
        layout->addWidget(m_solarProgress);
        m_solarPercent = new QLabel;
        m_solarPercent->setObjectName(QStringLiteral("subtitle"));
        layout->addWidget(m_solarPercent);
        auto *nextHeading = new QLabel(QStringLiteral("Next seasonal marker"));
        nextHeading->setObjectName(QStringLiteral("subtitle"));
        m_nextSolar = makeValueLabel();
        layout->addWidget(nextHeading);
        layout->addWidget(m_nextSolar);
        layout->addStretch();
        return card;
    }

    void updateReadings()
    {
        const QDateTime selectedLocal = m_dateTime->dateTime();
        const double timestamp = selectedLocal.toUTC().toSecsSinceEpoch();

        const double lunarDays = positiveModulo(
            (timestamp - kMoonEpochUnixSeconds) / kSecondsPerDay, kSynodicMonthDays);
        const double lunarPhase = lunarDays / kSynodicMonthDays;
        const double illumination = (1.0 - std::cos(2.0 * kPi * lunarPhase)) / 2.0;
        m_moon->setPhase(lunarPhase);
        m_moonPhase->setText(lunarPhaseName(lunarPhase));
        m_illumination->setText(QStringLiteral("%1% illuminated")
                                     .arg(qRound(illumination * 100.0)));
        m_moonAge->setText(QStringLiteral("Moon age: %1 days")
                               .arg(lunarDays, 0, 'f', 1));

        const int nextPhaseIndex = static_cast<int>(std::floor(lunarPhase * 4.0)) + 1;
        const double timeUntilPhase =
            nextPhaseIndex / 4.0 * kSynodicMonthDays - lunarDays;
        const QDateTime nextMoon = QDateTime::fromSecsSinceEpoch(
            qRound64(timestamp + timeUntilPhase * kSecondsPerDay));
        const QStringList moonMarkers = {QStringLiteral("First Quarter"), QStringLiteral("Full Moon"),
                                         QStringLiteral("Last Quarter"), QStringLiteral("New Moon")};
        m_nextMoon->setText(QStringLiteral("%1\n%2")
                                .arg(moonMarkers.at((nextPhaseIndex - 1) % 4),
                                     nextMoon.toString(QStringLiteral("ddd, d MMM yyyy  HH:mm"))));

        const double solarDays = positiveModulo(
            (timestamp - kSolarEpochUnixSeconds) / kSecondsPerDay, kTropicalYearDays);
        const double solarProgress = solarDays / kTropicalYearDays;
        const int seasonIndex = static_cast<int>(solarProgress * 4.0);
        const double seasonProgress = solarProgress * 4.0 - seasonIndex;
        const bool southernHemisphere = m_hemisphere->currentData().toBool();
        const QStringList seasons = seasonNames(southernHemisphere);
        const QStringList solarMarkers = {QStringLiteral("March Equinox"), QStringLiteral("June Solstice"),
                                          QStringLiteral("September Equinox"), QStringLiteral("December Solstice")};
        m_solarSeason->setText(QStringLiteral("%1\n%2% through this season")
                                   .arg(seasons.at(seasonIndex),
                                        QString::number(qRound(seasonProgress * 100.0))));
        m_solarProgress->setValue(qRound(solarProgress * 1000.0));
        m_solarPercent->setText(QStringLiteral("%1% through the tropical year")
                                    .arg(qRound(solarProgress * 100.0)));

        const int nextSolarIndex = (seasonIndex + 1) % 4;
        const double solarDaysUntilMarker =
            (nextSolarIndex / 4.0 - solarProgress + (nextSolarIndex == 0 ? 1.0 : 0.0))
            * kTropicalYearDays;
        const QDateTime nextSolar = QDateTime::fromSecsSinceEpoch(
            qRound64(timestamp + solarDaysUntilMarker * kSecondsPerDay));
        m_nextSolar->setText(QStringLiteral("%1\n%2")
                                 .arg(solarMarkers.at(nextSolarIndex),
                                      nextSolar.toString(QStringLiteral("ddd, d MMM yyyy"))));
    }

    QDateTimeEdit *m_dateTime = nullptr;
    QComboBox *m_hemisphere = nullptr;
    MoonWidget *m_moon = nullptr;
    QLabel *m_moonPhase = nullptr;
    QLabel *m_illumination = nullptr;
    QLabel *m_moonAge = nullptr;
    QLabel *m_nextMoon = nullptr;
    QLabel *m_solarSeason = nullptr;
    QLabel *m_solarPercent = nullptr;
    QLabel *m_nextSolar = nullptr;
    QProgressBar *m_solarProgress = nullptr;
};
} // namespace

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    TrackerWindow window;
    window.show();
    return app.exec();
}
