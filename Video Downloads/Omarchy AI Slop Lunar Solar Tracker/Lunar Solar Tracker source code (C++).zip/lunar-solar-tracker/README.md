# Luna & Sol — Cycle Tracker

A small cross-platform desktop application written in C++ with Qt 5 Widgets. It displays an estimated lunar phase, illumination, lunar age, the next major moon phase, and progress through the annual solar cycle. Choose a date/time to inspect a past or future reading, and select a hemisphere for the seasonal labels.

## Build

Requirements: CMake 3.16 or later, a C++17 compiler, and Qt 5.12 or later with the Widgets module.

```sh
cmake -S . -B build
cmake --build build
./build/lunar-solar-tracker
```

On Windows, launch `build/Debug/lunar-solar-tracker.exe` or
`build/Release/lunar-solar-tracker.exe`, depending on the selected build
configuration. Qt's platform plugin must be available at runtime.

## Calculation notes

The lunar estimate uses a mean synodic month of 29.530588853 days from a
reference new moon on 2000-01-06 18:14 UTC. The solar-year estimate uses an
average tropical year of 365.2422 days from the March equinox on 2000-03-20
07:35 UTC. Seasonal markers are evenly spaced quarter-year estimates, not
observed equinox and solstice times. Results are educational approximations;
the app is offline and does not calculate location-specific sunrise, sunset,
or moon visibility.
