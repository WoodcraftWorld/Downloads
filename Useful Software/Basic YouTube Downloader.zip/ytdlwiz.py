import os
from pathlib import Path
import sys
import pymsgbox
import yt_dlp


def main():
  # Determine the user's Downloads folder cross-platform
  downloads_path = str(Path.home() / "Downloads")

  # Step 1: Prompt for YouTube video link
  url = pymsgbox.prompt(
      text="Please enter the YouTube video link:",
      title="YouTube Downloader",
      default="",
  )

  # Check if user cancelled or left the prompt empty
  if not url:
    pymsgbox.alert("No URL provided. Exiting.", "Cancelled")
    sys.exit()

  # Step 2: Prompt for conversion options
  options = [
      "Re-encode to H.264/AAC MP4",
      "Re-encode to MP3",
      "Download native Opus (Stream 251)",
  ]

  choice = pymsgbox.confirm(
      text="Select your desired output format:",
      title="Format Selection",
      buttons=options,
  )

  # Check if user closed the box or clicked cancel
  if not choice or choice not in options:
    pymsgbox.alert("No option selected. Exiting.", "Cancelled")
    sys.exit()

  # Configure yt-dlp options based on the user's choice
  output_template = os.path.join(downloads_path, "%(title)s.%(ext)s")
  ydl_opts = {"outtmpl": output_template}

  if choice == options[0]:  # Re-encode to h264 aac mp4
    ydl_opts.update({
        "format": "bestvideo+bestaudio/best",
        "postprocessors": [{
            "key": "FFmpegVideoConvertor",
            "preferedformat": "mp4",
        }],
    })
  elif choice == options[1]:  # Re-encode to mp3
    ydl_opts.update({
        "format": "bestaudio/best",
        "postprocessors": [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }
        ],
    })
  elif choice == options[2]:  # Native opus 251
    ydl_opts.update({
        "format": "251",  # Format 251 is YouTube's native 160kbps Opus audio stream in webm
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "opus",
        }],
    })

  # Step 3: Download and convert
  try:
    pymsgbox.alert(
        "Download started! Click OK to begin. (The script will notify you when"
        " finished).",
        "Downloading...",
    )
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
      ydl.download([url])

    pymsgbox.alert(
        f"Download complete!\nSaved successfully to:\n{downloads_path}",
        "Success",
    )
  except Exception as e:
    pymsgbox.alert(f"An error occurred during download:\n{str(e)}", "Error")


if __name__ == "__main__":
  main()